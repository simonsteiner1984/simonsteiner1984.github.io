This distribution includes xml-apis-ext.jar from the XML Commons External
1.3.04 binary distribution, which can also be obtained from:

  http://xml.apache.org/mirrors.cgi

Source code is available from the XML Commons web site:

  http://xml.apache.org/commons/

xml-apis-ext.jar contains:

  - SAC 1.3
  - SMIL Java bindings
  - SVG 1.1 Java bindings

SAC 1.3, the SMIL Java bindings and the SVG 1.1 Java bindings are licensed
under the W3C Software License.  Related documentation is licensed under the
W3C Document License.  See LICENSE.dom-software.txt and
LICENSE.dom-documentation.txt.
